package APS;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

import java.time.LocalDateTime;

import controller.BidResult;
import controller.BiddingController;
import model.AuctionSale;
import model.Bid;
import model.Client;
import model.IndividualClient;

/** JMeter sampler for the APS Lab 10 classes: UC006 Place bid. */
public class ClientPerformanceTest2 implements JavaSamplerClient {

    @Override
    public void setupTest(JavaSamplerContext context) {
        // Optional: initialize resources if needed
    }

    @Override
    public SampleResult runTest(JavaSamplerContext context) {
        SampleResult result = new SampleResult();
        result.sampleStart(); // Start timing

        try {
            LocalDateTime now = LocalDateTime.now();

            // Create Client (Client is abstract, so use IndividualClient)
            Client client = new IndividualClient(101, "Fatima", "Doha");

            // Create an auction that is still open, starting at QAR 400
            AuctionSale auction = new AuctionSale(400.0, now.plusDays(1));

            // UC006 Place bid through the controller
            BiddingController controller = new BiddingController();
            controller.selectAuction(auction, now);
            BidResult outcome = controller.placeBid(client, 500.0, now);

            // Record the bid in the client's registration (UC006 step 5)
            client.addBid(new Bid(500.0, now));

            result.setSuccessful(outcome == BidResult.ACCEPTED);
            result.setResponseMessage("Bid result: " + outcome);
            result.setResponseCodeOK();

        } catch (Exception e) {
            result.setSuccessful(false);
            result.setResponseMessage("Error: " + e.getMessage());
            result.setResponseCode("500");
        } finally {
            result.sampleEnd(); // End timing
        }
        return result;
    }

    @Override
    public void teardownTest(JavaSamplerContext context) {
        // Optional: clean up resources if needed
    }

    @Override
    public Arguments getDefaultParameters() {
        return new Arguments();
    }
}
