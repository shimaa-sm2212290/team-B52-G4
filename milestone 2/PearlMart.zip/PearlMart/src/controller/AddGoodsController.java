package controller;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import inventory.InventoryContainer;
import model.InventoryItem;
import model.ItemInfo;

import java.time.LocalDate;

/** JavaFX controller + screen for UC04 - Add Goods (actor: Inventory Manager). */
public class AddGoodsController {
    private final InventoryContainer inventory;

    // screen state
    private String currentItemId;
    private boolean itemExists;

    // screen widgets
    private final TextField idField = new TextField();
    private final TextField nameField = new TextField();
    private final TextField priceField = new TextField();
    private final TextField manufacturerField = new TextField();
    private final TextField originField = new TextField();
    private final DatePicker expirationPicker = new DatePicker();
    private final TextField commentsField = new TextField();
    private final TextField quantityField = new TextField();
    private final Button confirmButton = new Button("Confirm Addition");
    private final Label modeLabel = new Label("Enter an item identifier / barcode and press Search.");
    private final Label proposedLabel = new Label();
    private final Label messageLabel = new Label();
    private final VBox view = new VBox(12);

    public AddGoodsController(InventoryContainer inventory) {
        this.inventory = inventory;
        buildView();
    }

    public Node getView() { return view; }

    // ------------------------------------------------------------------ UC04 operations

    /** 1. Inventory Manager enters/scans an identifier -> the system searches for it. */
    public void addGoods(String itemId) {
        clearMessage();
        if (itemId == null || itemId.trim().isEmpty()) { displayError("Item identifier / barcode is required."); return; }
        currentItemId = itemId.trim();
        InventoryItem item = inventory.searchItem(currentItemId);
        itemExists = item != null;
        proposedLabel.setText("");
        if (itemExists) {
            fillFields(item);
            setNewItemFieldsEnabled(false);
            modeLabel.setText("Existing item found: enter the quantity to ADD to its stock (currently " + item.getQuantity() + ").");
        } else {
            clearFields(false);
            setNewItemFieldsEnabled(true);
            modeLabel.setText("New item: enter name, selling price, manufacturer, origin, quantity (expiration date and comments are optional).");
        }
        quantityField.setDisable(false);
        confirmButton.setDisable(false);
    }

    /** 2/3. Actor enters the data of a new item and its quantity. */
    public void enterItemInfo(ItemInfo itemInfo, int quantity) {
        if (validate(itemInfo, quantity)) {
            confirmAddition(itemInfo, quantity);
        }
    }

    /** 3. Actor enters the quantity of an existing item. */
    public void enterQuantity(int quantity) {
        if (validateQuantity(quantity)) {
            displayProposedQuantity(inventory.getProposedQuantity(currentItemId, quantity));
        }
    }

    /** Validates required fields, uniqueness and quantity of a NEW item (2a, 3a). */
    public boolean validate(ItemInfo itemInfo, int quantity) {
        if (itemInfo.getItemId() == null || itemInfo.getItemId().isEmpty()) { displayError("Item identifier is required."); return false; }
        if (inventory.searchItem(itemInfo.getItemId()) != null) { displayError("Duplicate item identification: " + itemInfo.getItemId() + " already exists."); return false; }
        if (itemInfo.getName() == null || itemInfo.getName().isEmpty()) { displayError("Name is required."); return false; }
        if (itemInfo.getSellingPrice() <= 0) { displayError("Selling price must be greater than zero."); return false; }
        if (itemInfo.getManufacturer() == null || itemInfo.getManufacturer().isEmpty()) { displayError("Manufacturer is required."); return false; }
        if (itemInfo.getOrigin() == null || itemInfo.getOrigin().isEmpty()) { displayError("Origin is required."); return false; }
        return validateQuantity(quantity);
    }

    /** 3a. Quantity must be positive. */
    public boolean validateQuantity(int quantity) {
        if (quantity <= 0) { displayError("Quantity must be a positive number."); return false; }
        return true;
    }

    /** 4. Actor confirms the addition (button handler): reads the screen, then validates and commits. */
    public void confirmAddition() {
        clearMessage();
        if (currentItemId == null) { displayError("Search for an item first."); return; }
        Integer quantity = parseQuantity();
        if (quantity == null) return;

        if (itemExists) {
            if (!validateQuantity(quantity)) return;
            if (inventory.addQuantity(currentItemId, quantity)) {
                displayUpdatedItem(inventory.searchItem(currentItemId));
            } else {
                displayError("The update could not be committed. Stock is unchanged.");
            }
        } else {
            ItemInfo info = readItemInfo();
            if (info == null) return;
            if (!validate(info, quantity)) return;
            if (inventory.addItem(info, quantity)) {
                displayUpdatedItem(inventory.searchItem(currentItemId));
            } else {
                displayError("The item could not be added. Stock is unchanged.");
            }
        }
    }

    private void confirmAddition(ItemInfo info, int quantity) { // used by enterItemInfo
        if (inventory.addItem(info, quantity)) displayUpdatedItem(inventory.searchItem(info.getItemId()));
        else displayError("The item could not be added. Stock is unchanged.");
    }

    // ------------------------------------------------------------------ display operations

    public void displayError(String message) {
        messageLabel.setTextFill(Color.FIREBRICK);
        messageLabel.setText("Error: " + message);
    }

    public void displayProposedQuantity(int newQuantity) {
        proposedLabel.setText("Quantity after addition: " + newQuantity);
    }

    public void displayUpdatedItem(InventoryItem item) {
        messageLabel.setTextFill(Color.DARKGREEN);
        messageLabel.setText("Success: " + item.getItemId() + " - " + item.getName()
                + " | available quantity is now " + item.getQuantity());
        currentItemId = null;
        itemExists = false;
        idField.clear();
        clearFields(true);
        setNewItemFieldsEnabled(false);
        quantityField.setDisable(true);
        confirmButton.setDisable(true);
        proposedLabel.setText("");
        modeLabel.setText("Enter an item identifier / barcode and press Search.");
    }

    // ------------------------------------------------------------------ screen helpers

    private Integer parseQuantity() {
        try {
            return Integer.parseInt(quantityField.getText().trim());
        } catch (NumberFormatException e) {
            displayError("Quantity must be a whole number.");
            return null;
        }
    }

    private ItemInfo readItemInfo() {
        double price;
        try {
            price = Double.parseDouble(priceField.getText().trim());
        } catch (NumberFormatException e) {
            displayError("Selling price must be a number.");
            return null;
        }
        LocalDate exp = expirationPicker.getValue();
        return new ItemInfo(currentItemId, nameField.getText().trim(), price, manufacturerField.getText().trim(),
                originField.getText().trim(), exp, commentsField.getText().trim());
    }

    private void fillFields(InventoryItem i) {
        nameField.setText(i.getName());
        priceField.setText(String.valueOf(i.getSellingPrice()));
        manufacturerField.setText(i.getManufacturer());
        originField.setText(i.getOrigin());
        expirationPicker.setValue(i.getExpirationDate());
        commentsField.setText(i.getComments());
        quantityField.clear();
    }

    private void clearFields(boolean includeQuantity) {
        nameField.clear(); priceField.clear(); manufacturerField.clear(); originField.clear();
        expirationPicker.setValue(null); commentsField.clear();
        if (includeQuantity) quantityField.clear();
    }

    private void setNewItemFieldsEnabled(boolean enabled) {
        nameField.setDisable(!enabled); priceField.setDisable(!enabled); manufacturerField.setDisable(!enabled);
        originField.setDisable(!enabled); expirationPicker.setDisable(!enabled); commentsField.setDisable(!enabled);
    }

    private void clearMessage() { messageLabel.setText(""); }

    private void buildView() {
        Label title = new Label("UC04 - Add Goods");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button searchButton = new Button("Search");
        searchButton.setOnAction(e -> addGoods(idField.getText()));
        idField.setOnAction(e -> addGoods(idField.getText()));
        idField.setPromptText("Item identifier / barcode");
        HBox idRow = new HBox(8, new Label("Item ID:"), idField, searchButton);

        GridPane form = new GridPane();
        form.setHgap(10); form.setVgap(8);
        String[] labels = {"Name *", "Selling price *", "Manufacturer *", "Origin *", "Expiration date", "Comments", "Quantity *"};
        Node[] fields = {nameField, priceField, manufacturerField, originField, expirationPicker, commentsField, quantityField};
        for (int i = 0; i < labels.length; i++) {
            form.add(new Label(labels[i]), 0, i);
            form.add(fields[i], 1, i);
        }
        nameField.setPrefColumnCount(22);

        setNewItemFieldsEnabled(false);
        quantityField.setDisable(true);
        confirmButton.setDisable(true);
        confirmButton.setOnAction(e -> confirmAddition());
        // live preview of the new quantity for an existing item
        quantityField.textProperty().addListener((obs, old, text) -> {
            proposedLabel.setText("");
            if (itemExists && text != null && !text.trim().isEmpty()) {
                try { enterQuantity(Integer.parseInt(text.trim())); clearErrorIfProposed(); }
                catch (NumberFormatException ex) { displayError("Quantity must be a whole number."); }
            }
        });

        modeLabel.setWrapText(true);
        view.getChildren().addAll(title, idRow, modeLabel, form, proposedLabel, confirmButton, messageLabel);
        view.setPadding(new Insets(16));
    }

    private void clearErrorIfProposed() {
        if (!proposedLabel.getText().isEmpty()) clearMessage();
    }
}
