package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import inventory.InventoryContainer;
import model.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

/** JavaFX controller + screen for UC13 - Process Sale (actor: Salesperson), with UC14, UC15, UC16 and UC17. */
public class ProcessSaleController {
    private final InventoryContainer inventory;
    private final PriceCalculator calculator;
    private Sale currentSale;
    private Sale lastCompletedSale;

    private final TextField idField = new TextField();
    private final TextField quantityField = new TextField("1");
    private final TableView<SaleLine> linesTable = new TableView<>();
    private final ObservableList<SaleLine> lineData = FXCollections.observableArrayList();
    private final Label totalsLabel = new Label();
    private final TextArea receiptArea = new TextArea();
    private final Label messageLabel = new Label();
    private final Button startButton = new Button("Start New Sale");
    private final Button addButton = new Button("Add Item");
    private final Button totalButton = new Button("Request Total");
    private final Button confirmButton = new Button("Confirm Sale");
    private final Button cancelButton = new Button("Cancel Sale");
    private final Button receiptButton = new Button("Request Receipt");
    private final VBox view = new VBox(10);

    public ProcessSaleController(InventoryContainer inventory, PriceCalculator calculator) {
        this.inventory = inventory;
        this.calculator = calculator;
        buildView();
        setSaleActive(false);
    }

    public Node getView() { return view; }

    // ------------------------------------------------------------------ UC13 operations

    /** 1. Salesperson starts a new billing transaction -> pending sale. */
    public void startSale() {
        currentSale = Sale.create();
        lineData.clear();
        totalsLabel.setText("");
        receiptArea.clear();
        idField.clear();
        quantityField.setText("1");
        setSaleActive(true);
        displayInfo("New sale started. Scan or enter items.");
    }

    /** 2. Enter item + quantity: UC14 verifies availability, line keeps the current price. */
    public void enterItem(String itemId, int quantity) {
        if (currentSale == null) { displayError("Start a new sale first."); return; }
        String id = itemId == null ? "" : itemId.trim();
        InventoryItem item = inventory.searchItem(id);
        if (item == null) { displayError("Unrecognized item '" + id + "'. Correct the identifier."); return; } // 2a
        if (quantity <= 0) { displayError("Quantity must be a positive number."); return; }
        int wanted = quantity + currentSale.getQuantityOf(id);
        if (!inventory.verifyAvailability(id, wanted)) { // 2b (counts what is already in this sale)
            displayError("Insufficient stock for " + item.getName() + ". Available: " + item.getQuantity()
                    + ", already in this sale: " + currentSale.getQuantityOf(id) + ".");
            return;
        }
        currentSale.addLine(id, item.getSellingPrice(), quantity);
        lineData.setAll(currentSale.getLines());
        totalsLabel.setText("");
        displayInfo("Added " + quantity + " x " + item.getName() + ". Request the total when all items are added.");
        idField.clear();
        quantityField.setText("1");
        idField.requestFocus();
    }

    /** 4. Request the amount payable (UC15, which evaluates UC16). */
    public void requestTotal() {
        if (currentSale == null) { displayError("Start a new sale first."); return; }
        try {
            calculator.calculateTotal(currentSale);
        } catch (IllegalStateException e) { // 1a/2a/4a of UC15
            displayError(e.getMessage());
            return;
        }
        displayTotal(currentSale.getLines(), currentSale.getDiscount(), currentSale.getTax(), currentSale.getTotal());
    }

    /** 5a. UC17: cancel the pending sale - no stock is deducted. */
    public void cancelSale() {
        if (currentSale == null) return;
        currentSale.cancel();
        currentSale = null;
        displayCancellation();
    }

    /** 5. Confirm the sale: stock is re-checked, deducted once, movements recorded. */
    public void confirmSale() {
        if (currentSale == null) { displayError("Start a new sale first."); return; }
        if (currentSale.getLines().isEmpty()) { displayError("Add at least one item before confirming."); return; }
        if (!currentSale.isTotalCalculated()) { displayError("Request the total and review it before confirming."); return; }
        Sale sale = currentSale;
        if (inventory.finalizeSale(sale)) {
            lastCompletedSale = sale;
            currentSale = null;
            setSaleActive(false);
            receiptButton.setDisable(false);
            displayInfo("Sale confirmed. Stock was updated. Press 'Request Receipt'.");
        } else { // 5b
            displayError("The sale could not be finalized (stock changed or the update failed). Stock is unchanged: "
                    + "adjust the quantities and try again.");
        }
    }

    /** 6. Request the receipt of the completed sale. */
    public void requestReceipt() {
        if (lastCompletedSale == null) { displayError("There is no completed sale."); return; }
        displayReceipt(SalesReceipt.create(lastCompletedSale));
        lastCompletedSale = null;
        receiptButton.setDisable(true);
    }

    // ------------------------------------------------------------------ display operations

    public void displayError(String message) {
        messageLabel.setTextFill(Color.FIREBRICK);
        messageLabel.setText("Error: " + message);
    }

    private void displayInfo(String message) {
        messageLabel.setTextFill(Color.DARKGREEN);
        messageLabel.setText(message);
    }

    public void displayTotal(List<SaleLine> lines, double discount, double tax, double total) {
        double subtotal = 0;
        for (SaleLine l : lines) subtotal += l.getLineAmount();
        totalsLabel.setText(String.format("Subtotal: %.2f   Discount: -%.2f   Tax: +%.2f   TOTAL: %.2f",
                subtotal, discount, tax, total));
        displayInfo("Review the total, then confirm or cancel the sale.");
    }

    public void displayCancellation() {
        lineData.clear();
        totalsLabel.setText("");
        setSaleActive(false);
        displayInfo("Sale cancelled. No stock was deducted.");
    }

    public void displayReceipt(SalesReceipt r) {
        StringBuilder sb = new StringBuilder();
        sb.append("=========== PEARLMART SALES RECEIPT ===========\n");
        sb.append(String.format("Receipt no: %d%nDate: %s%n", r.getReceiptNo(),
                r.getIssueDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))));
        sb.append("-----------------------------------------------\n");
        for (SaleLine l : r.getSale().getLines()) {
            InventoryItem item = inventory.searchItem(l.getItemId());
            String name = item == null ? l.getItemId() : item.getName();
            sb.append(String.format("%-24s %3d x %8.2f = %9.2f%n", name, l.getQuantity(), l.getUnitPrice(), l.getLineAmount()));
        }
        sb.append("-----------------------------------------------\n");
        sb.append(String.format("Subtotal: %30.2f%nDiscount: %29.2f%nTax: %34.2f%nTOTAL: %32.2f%n",
                r.getSubtotal(), -r.getDiscount(), r.getTax(), r.getTotal()));
        sb.append("===============================================\nThank you!\n");
        receiptArea.setText(sb.toString());
        lineData.clear();
        totalsLabel.setText("");
        displayInfo("Sale completed. Receipt " + r.getReceiptNo() + " issued.");
    }

    // ------------------------------------------------------------------ screen

    private void setSaleActive(boolean active) {
        idField.setDisable(!active); quantityField.setDisable(!active);
        addButton.setDisable(!active); totalButton.setDisable(!active);
        confirmButton.setDisable(!active); cancelButton.setDisable(!active);
        startButton.setDisable(active);
        if (active) receiptButton.setDisable(true);
    }

    private void buildView() {
        Label title = new Label("UC13 - Process Sale");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        startButton.setOnAction(e -> startSale());
        idField.setPromptText("Item identifier / barcode");
        addButton.setOnAction(e -> addFromScreen());
        idField.setOnAction(e -> addFromScreen());
        totalButton.setOnAction(e -> requestTotal());
        confirmButton.setOnAction(e -> confirmSale());
        cancelButton.setOnAction(e -> cancelSale());
        receiptButton.setOnAction(e -> requestReceipt());
        receiptButton.setDisable(true);

        quantityField.setPrefColumnCount(5);
        HBox entry = new HBox(8, startButton, new Label("Item ID:"), idField, new Label("Qty:"), quantityField, addButton);

        TableColumn<SaleLine, String> cId = new TableColumn<>("Item ID");
        cId.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getItemId()));
        TableColumn<SaleLine, String> cName = new TableColumn<>("Name");
        cName.setCellValueFactory(c -> {
            InventoryItem i = inventory.searchItem(c.getValue().getItemId());
            return new javafx.beans.property.SimpleStringProperty(i == null ? "" : i.getName());
        });
        TableColumn<SaleLine, String> cQty = new TableColumn<>("Qty");
        cQty.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.valueOf(c.getValue().getQuantity())));
        TableColumn<SaleLine, String> cPrice = new TableColumn<>("Unit price");
        cPrice.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f", c.getValue().getUnitPrice())));
        TableColumn<SaleLine, String> cAmt = new TableColumn<>("Amount");
        cAmt.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f", c.getValue().getLineAmount())));
        linesTable.getColumns().addAll(cId, cName, cQty, cPrice, cAmt);
        linesTable.setItems(lineData);
        linesTable.setPrefHeight(180);
        linesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        totalsLabel.setStyle("-fx-font-weight: bold;");
        HBox actions = new HBox(8, totalButton, confirmButton, cancelButton, receiptButton);

        receiptArea.setEditable(false);
        receiptArea.setPrefRowCount(12);
        receiptArea.setStyle("-fx-font-family: 'monospaced';");
        receiptArea.setPromptText("The sales receipt appears here after the sale is confirmed.");

        messageLabel.setWrapText(true);
        view.getChildren().addAll(title, entry, linesTable, totalsLabel, actions, messageLabel, receiptArea);
        view.setPadding(new Insets(16));
    }

    private void addFromScreen() {
        if (currentSale == null) { displayError("Start a new sale first."); return; }
        int q;
        try { q = Integer.parseInt(quantityField.getText().trim()); }
        catch (NumberFormatException e) { displayError("Quantity must be a whole number."); return; }
        enterItem(idField.getText(), q);
    }
}
