package application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import controller.AddGoodsController;
import controller.ProcessSaleController;
import inventory.InventoryContainer;
import inventory.SampleData;
import model.InventoryItem;
import model.InventoryMovement;

/** PearlMart prototype: ONE shared InventoryContainer used by UC04 (Add Goods) and UC13 (Process Sale). */
public class Main extends Application {

    @Override
    public void start(Stage stage) {
        InventoryContainer inventory = new InventoryContainer();
        SampleData.load(inventory, 1000);

        AddGoodsController addGoods = new AddGoodsController(inventory);
        ProcessSaleController processSale = new ProcessSaleController(inventory, SampleData.defaultCalculator());

        TabPane tabs = new TabPane(
                tab("Add Goods (UC04)", addGoods.getView()),
                tab("Process Sale (UC13)", processSale.getView()),
                tab("Inventory", inventoryView(inventory)));
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        stage.setTitle("PearlMart - Milestone 2");
        stage.setScene(new Scene(tabs, 900, 720));
        stage.show();
    }

    private Tab tab(String title, javafx.scene.Node content) {
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        return new Tab(title, sp);
    }

    private VBox inventoryView(InventoryContainer inventory) {
        TextField filter = new TextField();
        filter.setPromptText("Filter by item ID or name");

        TableView<InventoryItem> items = new TableView<>();
        items.getColumns().add(col("Item ID", i -> i.getItemId()));
        items.getColumns().add(col("Name", i -> i.getName()));
        items.getColumns().add(col("Price", i -> String.format("%.2f", i.getSellingPrice())));
        items.getColumns().add(col("Available quantity", i -> String.valueOf(i.getQuantity())));
        items.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

        TableView<InventoryMovement> moves = new TableView<>();
        TableColumn<InventoryMovement, String> m1 = new TableColumn<>("Movement");
        m1.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getMovementId())));
        TableColumn<InventoryMovement, String> m2 = new TableColumn<>("Item ID");
        m2.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getItemId()));
        TableColumn<InventoryMovement, String> m3 = new TableColumn<>("Type");
        m3.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getType().name()));
        TableColumn<InventoryMovement, String> m4 = new TableColumn<>("Quantity");
        m4.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getQuantity())));
        TableColumn<InventoryMovement, String> m5 = new TableColumn<>("Date / time");
        m5.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDateTime().withNano(0).toString().replace('T', ' ')));
        moves.getColumns().addAll(m1, m2, m3, m4, m5);
        moves.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        moves.setPrefHeight(200);

        Runnable refresh = () -> {
            String f = filter.getText() == null ? "" : filter.getText().trim().toLowerCase();
            items.setItems(FXCollections.observableArrayList(inventory.getItems().stream()
                    .filter(i -> f.isEmpty() || i.getItemId().toLowerCase().contains(f) || i.getName().toLowerCase().contains(f))
                    .toList()));
            java.util.List<InventoryMovement> all = new java.util.ArrayList<>(inventory.getMovements());
            java.util.Collections.reverse(all); // newest first
            moves.setItems(FXCollections.observableArrayList(all));
        };
        inventory.addListener(refresh);
        filter.textProperty().addListener((o, a, b) -> refresh.run());
        refresh.run();

        VBox box = new VBox(10, new Label("Shared inventory (updated by both use cases)"), filter, items,
                new Label("Inventory movements (newest first)"), moves);
        box.setStyle("-fx-padding: 16;");
        VBox.setVgrow(items, javafx.scene.layout.Priority.ALWAYS);
        return box;
    }

    private TableColumn<InventoryItem, String> col(String title, java.util.function.Function<InventoryItem, String> f) {
        TableColumn<InventoryItem, String> c = new TableColumn<>(title);
        c.setCellValueFactory(x -> new SimpleStringProperty(f.apply(x.getValue())));
        return c;
    }

    public static void main(String[] args) { launch(args); }
}
