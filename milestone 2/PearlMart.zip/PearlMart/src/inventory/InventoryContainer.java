package inventory;

import model.*;

import java.util.*;

/**
 * The shared inventory. UC04 (Add Goods) and UC13 (Process Sale) both work on ONE instance of this class.
 * Every stock change is made together with its InventoryMovement; if anything fails nothing is kept.
 */
public class InventoryContainer {
    private final List<InventoryItem> items = new ArrayList<>();
    private final List<InventoryMovement> movements = new ArrayList<>();
    private final Map<String, InventoryItem> index = new HashMap<>(); // fast lookup by itemId
    private final List<Runnable> listeners = new ArrayList<>();

    // ---------- lookup ----------
    public synchronized InventoryItem searchItem(String itemId) {
        return itemId == null ? null : index.get(itemId.trim());
    }

    public synchronized List<InventoryItem> getItems() { return Collections.unmodifiableList(new ArrayList<>(items)); }
    public synchronized List<InventoryMovement> getMovements() { return Collections.unmodifiableList(new ArrayList<>(movements)); }
    public synchronized int size() { return items.size(); }

    // ---------- UC04 ----------
    /** Creates a new item and one ADD movement. False (no change) if the id is blank/duplicate or quantity <= 0. */
    public synchronized boolean addItem(ItemInfo info, int quantity) {
        if (info == null || info.getItemId() == null || info.getItemId().trim().isEmpty()) return false;
        if (quantity <= 0 || index.containsKey(info.getItemId())) return false;
        try {
            InventoryItem item = InventoryItem.create(info, quantity);
            InventoryMovement movement = InventoryMovement.create(item.getItemId(), MovementType.ADD, quantity);
            items.add(item);
            index.put(item.getItemId(), item);
            movements.add(movement);
        } catch (RuntimeException e) { // 4a: could not commit consistently -> keep stock unchanged
            items.removeIf(i -> i.getItemId().equals(info.getItemId()));
            index.remove(info.getItemId());
            return false;
        }
        fireChanged();
        return true;
    }

    /** quantity currently in stock + quantity being added, or -1 if the item does not exist. */
    public synchronized int getProposedQuantity(String itemId, int quantity) {
        InventoryItem item = searchItem(itemId);
        return item == null ? -1 : item.getQuantity() + quantity;
    }

    /** Increases an existing item and records one ADD movement. False (no change) when invalid. */
    public synchronized boolean addQuantity(String itemId, int quantity) {
        InventoryItem item = searchItem(itemId);
        if (item == null || quantity <= 0) return false;
        try {
            item.increaseQuantity(quantity);
            movements.add(InventoryMovement.create(itemId, MovementType.ADD, quantity));
        } catch (RuntimeException e) {
            return false;
        }
        fireChanged();
        return true;
    }

    // ---------- UC14 ----------
    /** Item exists, quantity is positive and does not exceed the current shared stock. */
    public synchronized boolean verifyAvailability(String itemId, int quantity) {
        InventoryItem item = searchItem(itemId);
        return item != null && quantity > 0 && quantity <= item.getQuantity();
    }

    // ---------- UC13 ----------
    /**
     * Confirms a sale: re-checks stock for every line (5b), then deducts every quantity exactly once and
     * records one SALE movement per line. All or nothing: on any problem the stock is restored.
     */
    public synchronized boolean finalizeSale(Sale sale) {
        if (sale == null || sale.getStatus() != TransactionStatus.PENDING || sale.getLines().isEmpty()) return false;
        for (SaleLine line : sale.getLines())
            if (!verifyAvailability(line.getItemId(), line.getQuantity())) return false;

        Map<String, Integer> before = new HashMap<>();
        int movementsBefore = movements.size();
        try {
            for (SaleLine line : sale.getLines()) {
                InventoryItem item = index.get(line.getItemId());
                before.put(item.getItemId(), item.getQuantity());
                item.decreaseQuantity(line.getQuantity());
                movements.add(InventoryMovement.create(item.getItemId(), MovementType.SALE, line.getQuantity()));
            }
            sale.complete();
        } catch (RuntimeException e) { // rollback
            for (Map.Entry<String, Integer> e2 : before.entrySet()) {
                InventoryItem item = index.get(e2.getKey());
                int diff = e2.getValue() - item.getQuantity();
                if (diff > 0) item.increaseQuantity(diff);
            }
            while (movements.size() > movementsBefore) movements.remove(movements.size() - 1);
            return false;
        }
        fireChanged();
        return true;
    }

    // ---------- change notification for the screens ----------
    public void addListener(Runnable listener) { listeners.add(listener); }
    private void fireChanged() { for (Runnable r : listeners) r.run(); }
}
