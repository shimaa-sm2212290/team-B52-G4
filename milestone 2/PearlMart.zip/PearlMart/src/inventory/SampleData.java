package inventory;

import model.ItemInfo;
import model.PriceCalculator;

import java.time.LocalDate;

/** Sample products and policy rules for the prototype (no real business data is available). */
public final class SampleData {
    private SampleData() {}

    /** Loads 10 named products plus generated ones until {@code total} items exist (default 1,000). */
    public static void load(InventoryContainer inv, int total) {
        String[][] named = {
            {"1001", "Basmati Rice 5kg", "24.50", "Al Wazzan", "India", "50"},
            {"1002", "Olive Oil 1L", "32.00", "Olea", "Spain", "30"},
            {"1003", "Fresh Milk 1L", "6.25", "Baladna", "Qatar", "100"},
            {"1004", "Whole Wheat Bread", "4.00", "Golden Bakery", "Qatar", "60"},
            {"1005", "Orange Juice 1L", "7.50", "Sunrise", "Egypt", "80"},
            {"1006", "Dates 500g", "15.00", "Palm Gold", "Saudi Arabia", "40"},
            {"1007", "Black Tea 100 bags", "11.75", "Lipton", "Kenya", "70"},
            {"1008", "Bottled Water 12 pack", "9.00", "Mai", "Qatar", "120"},
            {"1009", "Chicken Breast 1kg", "27.00", "Al Watania", "Qatar", "25"},
            {"1010", "Sugar 2kg", "8.50", "Domino", "Brazil", "5"},   // low stock to test insufficient quantity
        };
        for (String[] r : named) {
            inv.addItem(new ItemInfo(r[0], r[1], Double.parseDouble(r[2]), r[3], r[4],
                    LocalDate.now().plusMonths(6), "Sample product"), Integer.parseInt(r[5]));
        }
        for (int i = named.length + 1; i <= total; i++) {
            String id = String.valueOf(1000 + i);
            inv.addItem(new ItemInfo(id, "Sample Item " + id, 5 + (i % 40), "Sample Maker", "Qatar",
                    null, "Generated for the performance test"), 10 + (i % 90));
        }
    }

    /** Documented policy assumption: a few discount/tax rules, zero everywhere else. */
    public static PriceCalculator defaultCalculator() {
        PriceCalculator c = new PriceCalculator();
        c.setDiscountRate("1003", 0.10); // 10% off fresh milk
        c.setTaxRate("1002", 0.05);      // 5% tax on olive oil
        return c;
    }
}
