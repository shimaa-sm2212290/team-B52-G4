package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Parent of Sale (kept from Milestone 1). */
public class Transaction {
    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);
    private static final List<Transaction> LEDGER = new ArrayList<>();

    private final int transactionID;
    private final LocalDate date;
    private TransactionStatus status;

    protected Transaction() {
        this.transactionID = NEXT_ID.getAndIncrement();
        this.date = LocalDate.now();
        this.status = TransactionStatus.PENDING;
    }

    /** Stores the transaction in the (in-memory) ledger. */
    public void record() { LEDGER.add(this); }

    public static List<Transaction> getLedger() { return Collections.unmodifiableList(LEDGER); }

    public int getTransactionID() { return transactionID; }
    public LocalDate getDate() { return date; }
    public TransactionStatus getStatus() { return status; }
    protected void setStatus(TransactionStatus status) { this.status = status; }
}
