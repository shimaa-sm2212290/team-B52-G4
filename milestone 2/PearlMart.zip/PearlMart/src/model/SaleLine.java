package model;

/** One purchased item in a sale; keeps the price at transaction time. */
public class SaleLine {
    private final String itemId;
    private int quantity;
    private final double unitPrice;

    public SaleLine(String itemId, double unitPrice, int quantity) {
        this.itemId = itemId;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    void addQuantity(int extra) { quantity += extra; }

    public String getItemId() { return itemId; }
    public int getQuantity() { return quantity; }
    public double getUnitPrice() { return unitPrice; }
    public double getLineAmount() { return unitPrice * quantity; }
}
