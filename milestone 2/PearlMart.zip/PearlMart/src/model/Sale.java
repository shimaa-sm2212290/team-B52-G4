package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A (pending, completed or cancelled) customer sale. */
public class Sale extends Transaction {
    private final List<SaleLine> lines = new ArrayList<>();
    private double subtotal;
    private double discount;
    private double tax;
    private double total;
    private boolean totalCalculated;

    private Sale() { super(); }

    /** create() message: a new pending sale context. */
    public static Sale create() { return new Sale(); }

    public void addLine(String itemId, double price, int quantity) {
        if (getStatus() != TransactionStatus.PENDING) throw new IllegalStateException("Sale is not pending");
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        for (SaleLine line : lines) {
            if (line.getItemId().equals(itemId)) { line.addQuantity(quantity); totalCalculated = false; return; }
        }
        lines.add(new SaleLine(itemId, price, quantity));
        totalCalculated = false;
    }

    /** Quantity of an item already in this sale (used by UC14 so the same item is not over-sold). */
    public int getQuantityOf(String itemId) {
        for (SaleLine line : lines) if (line.getItemId().equals(itemId)) return line.getQuantity();
        return 0;
    }

    /** UC17 - Cancel Current Receipt: no stock is touched. */
    public void cancel() {
        setStatus(TransactionStatus.CANCELLED);
        record();
    }

    public void complete() {
        setStatus(TransactionStatus.COMPLETED);
        record();
    }

    /** Called by PriceCalculator only. */
    void setAmounts(double subtotal, double discount, double tax, double total) {
        this.subtotal = subtotal; this.discount = discount; this.tax = tax; this.total = total;
        this.totalCalculated = true;
    }

    public List<SaleLine> getLines() { return Collections.unmodifiableList(lines); }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public double getTax() { return tax; }
    public double getTotal() { return total; }
    public boolean isTotalCalculated() { return totalCalculated; }
}
