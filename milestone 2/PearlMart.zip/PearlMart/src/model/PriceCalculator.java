package model;

import java.util.HashMap;
import java.util.Map;

/**
 * UC15 - Calculate Payable Amount (uses the rules of UC16 - Apply Discount and Tax Rules).
 * Policy assumption: rates are configurable per item and are ZERO when no rule applies.
 */
public class PriceCalculator {
    private final Map<String, Double> discountRates = new HashMap<>();
    private final Map<String, Double> taxRates = new HashMap<>();

    public void setDiscountRate(String itemId, double rate) { discountRates.put(itemId, rate); }
    public void setTaxRate(String itemId, double rate) { taxRates.put(itemId, rate); }

    /** Calculates subtotal, discount, tax and final total and stores them in the sale. */
    public double calculateTotal(Sale sale) {
        if (sale.getLines().isEmpty())
            throw new IllegalStateException("No valid sale lines: cannot calculate a payable amount");
        applyDiscountAndTax(sale);
        return sale.getTotal();
    }

    /** UC16: evaluate discount and tax rules for every line. */
    public void applyDiscountAndTax(Sale sale) {
        double subtotal = 0, discount = 0, tax = 0;
        for (SaleLine line : sale.getLines()) {
            double d = rate(discountRates, line.getItemId());
            double t = rate(taxRates, line.getItemId());
            double amount = line.getLineAmount();
            double lineDiscount = amount * d;
            subtotal += amount;
            discount += lineDiscount;
            tax += (amount - lineDiscount) * t;
        }
        subtotal = round(subtotal); discount = round(discount); tax = round(tax);
        sale.setAmounts(subtotal, discount, tax, round(subtotal - discount + tax));
    }

    private double rate(Map<String, Double> rates, String itemId) {
        double r = rates.getOrDefault(itemId, 0.0);
        if (r < 0 || r > 1) throw new IllegalStateException("Policy data cannot be evaluated for item " + itemId);
        return r;
    }

    private static double round(double v) { return Math.round(v * 100.0) / 100.0; }
}
