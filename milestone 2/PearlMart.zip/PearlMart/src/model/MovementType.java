package model;

public enum MovementType { ADD, SALE }
