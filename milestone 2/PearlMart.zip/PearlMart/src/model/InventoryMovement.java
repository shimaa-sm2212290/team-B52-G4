package model;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

/** One recorded stock change (ADD from UC04 or SALE from UC13). */
public class InventoryMovement {
    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);

    private final int movementId;
    private final String itemId;
    private final MovementType type;
    private final int quantity;
    private final LocalDateTime dateTime;

    private InventoryMovement(String itemId, MovementType type, int quantity) {
        this.movementId = NEXT_ID.getAndIncrement();
        this.itemId = itemId;
        this.type = type;
        this.quantity = quantity;
        this.dateTime = LocalDateTime.now();
    }

    public static InventoryMovement create(String itemId, MovementType type, int quantity) {
        return new InventoryMovement(itemId, type, quantity);
    }

    public int getMovementId() { return movementId; }
    public String getItemId() { return itemId; }
    public MovementType getType() { return type; }
    public int getQuantity() { return quantity; }
    public LocalDateTime getDateTime() { return dateTime; }
}
