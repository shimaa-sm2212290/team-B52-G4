package model;

import java.time.LocalDate;

/** A product kept in the shared inventory. */
public class InventoryItem {
    private final String itemId;
    private final String name;
    private final double sellingPrice;
    private final String manufacturer;
    private final String origin;
    private final LocalDate expirationDate;
    private final String comments;
    private int availableQuantity;

    private InventoryItem(ItemInfo info, int quantity) {
        this.itemId = info.getItemId();
        this.name = info.getName();
        this.sellingPrice = info.getSellingPrice();
        this.manufacturer = info.getManufacturer();
        this.origin = info.getOrigin();
        this.expirationDate = info.getExpirationDate();
        this.comments = info.getComments();
        this.availableQuantity = quantity;
    }

    /** create(itemInfo, quantity) message from the sequence diagram. */
    public static InventoryItem create(ItemInfo info, int quantity) {
        return new InventoryItem(info, quantity);
    }

    public int getQuantity() { return availableQuantity; }

    public void increaseQuantity(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        availableQuantity += quantity;
    }

    public void decreaseQuantity(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        if (quantity > availableQuantity) throw new IllegalStateException("Insufficient stock for " + itemId);
        availableQuantity -= quantity;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public double getSellingPrice() { return sellingPrice; }
    public String getManufacturer() { return manufacturer; }
    public String getOrigin() { return origin; }
    public LocalDate getExpirationDate() { return expirationDate; }
    public String getComments() { return comments; }
}
