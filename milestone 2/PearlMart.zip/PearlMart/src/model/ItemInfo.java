package model;

import java.time.LocalDate;

/** Data carrier: the information entered for a NEW item in UC04 (Add Goods). */
public class ItemInfo {
    private final String itemId;
    private final String name;
    private final double sellingPrice;
    private final String manufacturer;
    private final String origin;
    private final LocalDate expirationDate; // optional (may be null)
    private final String comments;

    public ItemInfo(String itemId, String name, double sellingPrice, String manufacturer,
                    String origin, LocalDate expirationDate, String comments) {
        this.itemId = itemId;
        this.name = name;
        this.sellingPrice = sellingPrice;
        this.manufacturer = manufacturer;
        this.origin = origin;
        this.expirationDate = expirationDate;
        this.comments = comments;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public double getSellingPrice() { return sellingPrice; }
    public String getManufacturer() { return manufacturer; }
    public String getOrigin() { return origin; }
    public LocalDate getExpirationDate() { return expirationDate; }
    public String getComments() { return comments; }
}
