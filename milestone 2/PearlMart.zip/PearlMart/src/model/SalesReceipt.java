package model;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

/** Final receipt of a completed sale. */
public class SalesReceipt {
    private static final AtomicInteger NEXT_NO = new AtomicInteger(1);

    private final int receiptNo;
    private final LocalDateTime issueDate;
    private final Sale sale;
    private final double subtotal;
    private final double discount;
    private final double tax;
    private final double total;

    private SalesReceipt(Sale sale) {
        this.receiptNo = NEXT_NO.getAndIncrement();
        this.issueDate = LocalDateTime.now();
        this.sale = sale;
        this.subtotal = sale.getSubtotal();
        this.discount = sale.getDiscount();
        this.tax = sale.getTax();
        this.total = sale.getTotal();
    }

    public static SalesReceipt create(Sale sale) {
        if (sale.getStatus() != TransactionStatus.COMPLETED)
            throw new IllegalStateException("A receipt can only be issued for a completed sale");
        return new SalesReceipt(sale);
    }

    public int getReceiptNo() { return receiptNo; }
    public LocalDateTime getIssueDate() { return issueDate; }
    public Sale getSale() { return sale; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public double getTax() { return tax; }
    public double getTotal() { return total; }
}
